﻿// graph.c
#include <stdio.h>
#include <limits.h>
#include "graph.h"

void readGraphFromFile(Graph *g, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Nepavyko atidaryti failo: %s\n", filename);
        return;
    }
    fscanf(file, "%d", &g->n);
    for (int i = 0; i < g->n; i++) {
        for (int j = 0; j < g->n; j++) {
            fscanf(file, "%d", &g->adjacency[i][j]);
            if (g->adjacency[i][j] == 0 && i != j)
                g->adjacency[i][j] = INF;
        }
    }
    fclose(file);
}

void printGraph(Graph g) {
    printf("\nKaimynystes matrica:\n");
    for (int i = 0; i < g.n; i++) {
        for (int j = 0; j < g.n; j++) {
            if (g.adjacency[i][j] == INF)
                printf("INF ");
            else
                printf("%3d ", g.adjacency[i][j]);
        }
        printf("\n");
    }
}

int findMinKey(int key[], int mstSet[], int n) {
    int min = INF, min_index = -1;
    for (int v = 0; v < n; v++) {
        if (mstSet[v] == 0 && key[v] < min) {
            min = key[v];
            min_index = v;
        }
    }
    return min_index;
}

void primMST(Graph g) {
    int parent[MAX];
    int key[MAX];
    int mstSet[MAX] = {0};

    for (int i = 0; i < g.n; i++) {
        key[i] = INF;
        parent[i] = -1;
    }
    key[0] = 0;

    for (int count = 0; count < g.n - 1; count++) {
        int u = findMinKey(key, mstSet, g.n);
        mstSet[u] = 1;

        for (int v = 0; v < g.n; v++) {
            if (g.adjacency[u][v] && mstSet[v] == 0 && g.adjacency[u][v] < key[v]) {
                parent[v] = u;
                key[v] = g.adjacency[u][v];
            }
        }
    }

    int total_weight = 0;
    printf("\nMinimalus jungiamasis medis:\n");
    for (int i = 1; i < g.n; i++) {
        printf("(%d, %d) svoris: %d\n", parent[i] + 1, i + 1, g.adjacency[i][parent[i]]);
        total_weight += g.adjacency[i][parent[i]];
    }
    printf("Bendras svoris: %d\n", total_weight);
}
