﻿// main.c
#include <stdio.h>
#include "graph.h"

int main() {
    Graph g;

    printf("GRAFO 1 ANALIZE:\n");
    readGraphFromFile(&g, "input.txt");
    printGraph(g);
    primMST(g);

    printf("\nGRAFO 2 ANALIZE:\n");
    readGraphFromFile(&g, "input2.txt");
    printGraph(g);
    primMST(g);

    return 0;
}
