﻿// graph.h
#ifndef GRAPH_H
#define GRAPH_H

#define MAX 100
#define INF 9999

typedef struct {
    int n;
    int adjacency[MAX][MAX];
} Graph;

void readGraphFromFile(Graph *g, const char *filename);
void printGraph(Graph g);
void primMST(Graph g);
int findMinKey(int key[], int mstSet[], int n);

#endif
