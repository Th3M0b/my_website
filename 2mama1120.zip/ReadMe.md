# Subset Sum Problem Solution (Variant 11)

## Problem Description
The task is to find all non-empty subsets of a given set of integers that sum to zero.

## Implementation
The solution implements:
1. **Brute-force search** (checks all possible subsets)
2. **First match search** (stops after finding first solution)
3. **Timeout handling** (can limit search time)
4. **Progress reporting** (shows % complete)

## Test Cases
Tested with:
1. `{-7, -3, -2, 5, 8}` → `{-3, -2, 5}`
2. `{1, 2, 3, -1}` → multiple solutions
3. `{-4, 3, 7, -6, 1, -3}` → multiple solutions
4. `{1, 2, 3, 4}` → no solution

## Usage