#include "sum_zero.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

static clock_t start_time;
static bool timeout_reached = false;

void checkTimeout(int timeout_ms) {
    if (timeout_ms > 0 && (clock() - start_time) * 1000 / CLOCKS_PER_SEC >= timeout_ms) {
        timeout_reached = true;
    }
}

bool isNumber(const char* str) {
    char* endptr;
    strtol(str, &endptr, 10);
    return (*endptr == '\0');
}

void handleInput(int argc, char* argv[], int* numbers, int* n, 
    SearchMode* mode, int* timeout, char** filename) 
{
*mode = FIRST_MATCH; // Default mode
*timeout = 0;
*filename = NULL;
*n = 0;

for (int i = 1; i < argc; i++) {
if (*n >= MAX_SIZE) {
fprintf(stderr, "Warning: Maximum input size (%d) reached\n", MAX_SIZE);
break;
}

if (strcmp(argv[i], "-mode") == 0) {
if (i+1 >= argc) {
    fprintf(stderr, "Error: -mode requires an argument\n");
    exit(1);
}
i++;
if (strcmp(argv[i], "fullSearch") == 0) {
    *mode = FULL_SEARCH;
} else if (strcmp(argv[i], "firstMatchSearch") == 0) {
    *mode = FIRST_MATCH;
} else {
    fprintf(stderr, "Error: Invalid mode '%s'\n", argv[i]);
    exit(1);
}
}
else if (strcmp(argv[i], "-timeout") == 0) {
if (i+1 >= argc) {
    fprintf(stderr, "Error: -timeout requires a numeric argument\n");
    exit(1);
}
*timeout = atoi(argv[++i]);
}
else {
// Try to open as file first
FILE* file = fopen(argv[i], "r");
if (file) {
    *filename = argv[i];
    int value;
    while (fscanf(file, "%d", &value) == 1 && *n < MAX_SIZE) {
        numbers[(*n)++] = value;
    }
    fclose(file);
} 
else {
    // Treat as number
    char* endptr;
    long num = strtol(argv[i], &endptr, 10);
    if (*endptr != '\0') {
        fprintf(stderr, "Error: '%s' is neither a valid number nor a readable file\n", argv[i]);
        exit(1);
    }
    numbers[(*n)++] = (int)num;
}
}
}
}


bool findSubsets(int* numbers, int n, Subset** results, int* result_count, 
    int* result_capacity, SearchMode mode, int timeout_ms, int* progress) 
{
if (n <= 0 || numbers == NULL || results == NULL) {
fprintf(stderr, "Invalid arguments to findSubsets\n");
return false;
}

start_time = clock();
timeout_reached = false;
*result_count = 0;
*progress = 0;

// Initialize results array
*results = malloc(INIT_RESULT_SIZE * sizeof(Subset));
if (!*results) {
fprintf(stderr, "Memory allocation failed\n");
return false;
}
*result_capacity = INIT_RESULT_SIZE;

long total_subsets = (1L << n) - 1;
if (total_subsets <= 0) return false;

for (long mask = 1; mask <= total_subsets && !timeout_reached; mask++) {
int sum = 0;
int count = 0;
bool has_non_zero = false;

for (int i = 0; i < n; i++) {
if (mask & (1L << i)) {
    sum += numbers[i];
    count++;
    if (numbers[i] != 0) has_non_zero = true;
}
}

if (sum == 0 && has_non_zero) {
// Grow array if needed
if (*result_count >= *result_capacity) {
    *result_capacity *= 2;
    Subset* new_results = realloc(*results, *result_capacity * sizeof(Subset));
    if (!new_results) {
        fprintf(stderr, "Memory reallocation failed\n");
        free(*results);
        return false;
    }
    *results = new_results;
}

// Store subset
(*results)[*result_count].elements = malloc(count * sizeof(int));
if (!(*results)[*result_count].elements) {
    fprintf(stderr, "Memory allocation for subset failed\n");
    return false;
}

int pos = 0;
for (int i = 0; i < n; i++) {
    if (mask & (1L << i)) {
        (*results)[*result_count].elements[pos++] = numbers[i];
    }
}
(*results)[*result_count].size = count;
(*result_count)++;

if (mode == FIRST_MATCH) {
    *progress = 100;
    return true;
}
}

*progress = (int)((mask * 100) / total_subsets);
checkTimeout(timeout_ms);
}

*progress = 100;
return (*result_count > 0);
}

void printSubsets(Subset* subsets, int count) {
    if (!subsets || count <= 0) {
        printf("No subsets sum to 0.\n");
        return;
    }

    printf("Found %d subset%s that sum to 0:\n", count, count > 1 ? "s" : "");
    for (int i = 0; i < count; i++) {
        if (!subsets[i].elements || subsets[i].size <= 0) continue;
        
        printf("  Subset %d: { ", i+1);
        for (int j = 0; j < subsets[i].size; j++) {
            printf("%d", subsets[i].elements[j]);
            if (j < subsets[i].size - 1) printf(", ");
        }
        printf(" }\n");
    }
}

void freeSubsets(Subset* subsets, int count) {
    if (!subsets) return;
    for (int i = 0; i < count; i++) {
        free(subsets[i].elements);
    }
}

void printUsage(char* program_name) {
    fprintf(stderr, "\nSubset Sum Finder - Version 2.0\n");
    fprintf(stderr, "Usage: %s [INPUT] [OPTIONS]\n\n", program_name);
    fprintf(stderr, "INPUT:\n");
    fprintf(stderr, "  <numbers>       Space-separated numbers (e.g., 1 -2 3)\n");
    fprintf(stderr, "  <filename>      File containing numbers\n");
    fprintf(stderr, "  -               Read from standard input\n\n");
    fprintf(stderr, "OPTIONS:\n");
    fprintf(stderr, "  -                                                                 mode <mode>    Search mode (default: firstMatchSearch)\n");
    fprintf(stderr, "     fullSearch       Find all subsets\n");
    fprintf(stderr, "     firstMatchSearch Stop after first solution\n");
    fprintf(stderr, "  -timeout <ms>   Maximum search time in milliseconds\n");
    fprintf(stderr, "Examples:\n");
    fprintf(stderr, "  %s -7 -3 -2 5 8\n", program_name);
    fprintf(stderr, "  %s numbers.txt -mode fullSearch\n", program_name);
    fprintf(stderr, "  echo \"1 -1 2 -2\" | %s -\n", program_name);
    fprintf(stderr, "\nNote: Subsets must contain at least one non-zero element.\n");
}