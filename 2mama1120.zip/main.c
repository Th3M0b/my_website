#include "sum_zero.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }

    int numbers[MAX_SIZE];
    int n = 0;
    SearchMode mode = FIRST_MATCH;
    int timeout_ms = 0;
    char* filename = NULL;
    
    handleInput(argc, argv, numbers, &n, &mode, &timeout_ms, &filename);

    if (n == 0) {
        fprintf(stderr, "Error: No valid numbers provided\n");
        printUsage(argv[0]);
        return 1;
    }

    Subset* results = NULL;
    int result_count = 0;
    int result_capacity = 0;
    int progress = 0;
    
    bool found = findSubsets(numbers, n, &results, &result_count, &result_capacity,
                           mode, timeout_ms, &progress);
    
    if (timeout_ms > 0 && progress < 100) {
        printf("Timeout reached. Progress: %d%%\n", progress);
    }

    printSubsets(results, result_count);
    freeSubsets(results, result_count);

    return found ? 0 : 1;
}