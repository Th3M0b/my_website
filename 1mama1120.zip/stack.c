// stack.c
#include "stack.h"
#include "list.h"
#include <stdlib.h>
#include <string.h>

Stack create(void) {
    Stack stack;
    stack.head = NULL;
    stack.size = 0;
    stack.destroyed = false;
    return stack;
}

int destroy(Stack *stack) {
    if (!stack || stack->destroyed) return -1;  // Check flag
    
    destroyList(&stack->head);
    stack->size = 0;
    stack->destroyed = true;  // Mark as destroyed
    return 0;
}

stack_t count(const Stack stack) {
    return stack.size;
}

bool isEmpty(const Stack stack) {
    return stack.size == 0 || stack.head == NULL;
}

bool isFull(void) {
    return false; // Stekas niekada nėra pilnas (nebent trūksta atminties)
}

int push(Stack *stack, const Item item) {
    if (!stack || stack->destroyed) return -1;  // Block destroyed stacks

    Item *new_item = malloc(sizeof(Item));
    if (!new_item) return -2;

    *new_item = item;
    Node *new_head = insertAt(stack->head, new_item, 0);
    if (!new_head) {
        free(new_item);
        return -3;
    }

    stack->head = new_head;
    stack->size++;
    return 0;
}

int pop(Stack *stack, Item **item) {
    if (!stack || !item || isEmpty(*stack) || stack->destroyed) return -1;
    
    void *value = removeAtNode(&stack->head, 0);
    if (!value) return -1;
    
    *item = (Item*)value;
    stack->size--;
    return 0;
}

int top(Stack stack, Item **item) {
    if (isEmpty(stack) || !item || stack.destroyed) return -1;
    
    void *value = valueAt(stack.head, 0);
    if (!value) return -1;
    
    *item = (Item*)value;
    return 0;
}

Stack clone(Stack stack) {
    Stack new_stack = create();
    if (isEmpty(stack)) return new_stack;

    // Kopijuojame elementus atvirkštine tvarka, kad išlaikyti eiliškumą
    Node *current = stack.head->prev; // Pradedame nuo paskutinio elemento
    do {
        Item *val = (Item*)current->value;
        if (push(&new_stack, *val) != 0) {
            destroy(&new_stack);
            return create(); // Grąžiname tuščią steką klaidos atveju
        }
        current = current->prev;
    } while (current != stack.head->prev);
    
    return new_stack;
}

char *toString(Stack stack, char *(*itemToString)(Item*)) {
    if (isEmpty(stack) || !itemToString) return NULL;

    size_t size = sizeList(stack.head);
    char **str_arr = malloc(size * sizeof(char*));
    if (!str_arr) return NULL;

    // Surinkti elementų eilutes ir skaičiuoti bendrą ilgį
    Node *current = stack.head;
    size_t total_len = 0;
    for (size_t i = 0; i < size; i++) {
        char *str = itemToString((Item*)current->value);
        if (!str) {
            for (size_t j = 0; j < i; j++) free(str_arr[j]);
            free(str_arr);
            return NULL;
        }
        str_arr[i] = str;
        total_len += strlen(str);      // Pridedame teksto ilgį
        if (i < size - 1) total_len += 2; // Tarpų tarp elementų
        current = current->next;
    }

    // Sukurti rezultato eilutę
    char *result = malloc(total_len + 1); // +1 dėl NULL terminatoriaus
    if (!result) {
        for (size_t i = 0; i < size; i++) free(str_arr[i]);
        free(str_arr);
        return NULL;
    }

    // Suformuoti galutinę eilutę be laužtinių skliaustų
    char *ptr = result;
    for (size_t i = 0; i < size; i++) {
        strcpy(ptr, str_arr[i]);
        ptr += strlen(str_arr[i]);
        if (i < size - 1) {
            strcpy(ptr, ", ");
            ptr += 2;
        }
        free(str_arr[i]); // Atlaisvinti tarpinę eilutę
    }
    *ptr = '\0'; // Užbaigti eilutę

    free(str_arr);
    return result;

}