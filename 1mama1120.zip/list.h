// list.h
#ifndef LIST_H
#define LIST_H

#include <stddef.h>

// Dvipusio žiedinio sąrašo mazgo struktūra
typedef struct Node{
	void *value;		 // Nuoroda į duomenis
	struct Node *next;	 // Nuoroda į kitą mazgą sąraše
	struct Node *prev;	 // Nuoroda į ankstesnį mazgą sąraše
} Node;


// Sunaikina visą sąrašą ir atlaisvina mazgų atmintį
void destroyList(Node **head);

// Gražina sąrašo elementų skaičių
size_t sizeList(Node *head);

// Gražina nuorodą į mazgą pagal indeksą. Jei indeksas neteisingas, grąžina NULL.
Node *nodeAt(Node *head, size_t index);

// Įterpia naują elementą į sąrašą pagal indeksą.
// Jei index == 0, įterpia prieš head, jei index == 1 – po head.
Node *insertAt(Node *head, void *data, size_t index);

// Pašalina mazgą pagal indeksą ir grąžina nuorodą į jo value.
// Mazgo value atmintis neatlaisvinama.
void *removeAtNode(Node **head, size_t index);

// Gražina reikšmę (value) pagal indeksą
void *valueAt(Node *head, size_t index);

#endif