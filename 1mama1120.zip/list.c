// list.c
#include "list.h"
#include <stdlib.h>

// Sunaikina visą sąrašą ir atlaisvina mazgų atmintį
void destroyList(Node **head) {
    if (head == NULL || *head == NULL) return;

    Node *current = *head;
    Node *last = current->prev;

    // Pertraukiame cikliškumą
    if (last != NULL) last->next = NULL;
    current->prev = NULL;

    // Atlaisviname visus mazgus
    while (current != NULL) {
        Node *next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

// Grąžina sąrašo elementų skaičių
size_t sizeList(Node *head) {
    if (head == NULL) return 0;

    size_t count = 0;
    Node *current = head;
    do {
        count++;
        current = current->next;
    } while (current != head);

    return count;
}

// Grąžina mazgą pagal indeksą
Node *nodeAt(Node *head, size_t index) {
    if (head == NULL) return NULL;

    Node *current = head;
    size_t count = 0;

    do {
        if (count++ == index) return current;
        current = current->next;
    } while (current != head);

    return NULL;
}

// Įterpia naują elementą į sąrašą pagal indeksą
Node *insertAt(Node *head, void *data, size_t index) {
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL) return head;
    newNode->value = data;

    if (head == NULL) { // Tuščias sąrašas
        newNode->next = newNode;
        newNode->prev = newNode;
        return newNode;
    }

    size_t size = sizeList(head);
    if (index > size) index = size;

    if (index == 0) { // Įterpimas prieš head
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev->next = newNode;
        head->prev = newNode;
        head = newNode;
    } 
    else if (index == size) { // Įterpimas gale
        Node *last = head->prev;
        newNode->prev = last;
        newNode->next = head;
        last->next = newNode;
        head->prev = newNode;
    } 
    else { // Įterpimas viduryje
        Node *prevNode = nodeAt(head, index - 1);
        Node *nextNode = prevNode->next;

        newNode->prev = prevNode;
        newNode->next = nextNode;
        prevNode->next = newNode;
        nextNode->prev = newNode;
    }

    return head;
}

// Pašalina mazgą pagal indeksą ir grąžina jo reikšmę
void *removeAtNode(Node **head, size_t index) {
    if (head == NULL || *head == NULL) return NULL;

    Node *target = nodeAt(*head, index);
    if (target == NULL) return NULL;

    void *value = target->value;

    if (target->next == target) { // Vienintelis mazgas
        free(target);
        *head = NULL;
    } 
    else {
        target->prev->next = target->next;
        target->next->prev = target->prev;

        if (target == *head) *head = target->next; // Atnaujiname head
        free(target);
    }

    return value;
}

// Grąžina reikšmę pagal indeksą
void *valueAt(Node *head, size_t index) {
    Node *node = nodeAt(head, index);
    return (node != NULL) ? node->value : NULL;
}