// test.c
#include "stack.h"
#include <stdio.h>
#include <stdlib.h>  // PRIDĖTA: dėl malloc/free
#include <string.h>  // PRIDĖTA: dėl strcmp
#include <assert.h>

// Pagalbinė funkcija toString konversijai
char* itemToString(Item *item) {
    char *buffer = malloc(20); // Dinaminė atmintis kiekvienam elementui
    snprintf(buffer, 20, "%d", *item);
    return buffer;
}

// Testai
void test_create_destroy() {
    Stack s = create();
    assert(isEmpty(s) == true);
    assert(count(s) == 0);
    assert(destroy(&s) == 0);
    printf("test_create_destroy: OK\n");
}

void test_push_pop() {
    Stack s = create();
    Item *val;

    // Push test
    assert(push(&s, 10) == 0);
    assert(count(s) == 1);
    assert(push(&s, 20) == 0);
    assert(count(s) == 2);

    // Pop test
    assert(pop(&s, &val) == 0);
    assert(*val == 20);
    free(val);
    assert(pop(&s, &val) == 0);
    assert(*val == 10);
    free(val);
    assert(isEmpty(s) == true);

    // Pop tuščiam stekui
    assert(pop(&s, &val) == -1);
    printf("test_push_pop: OK\n");
    destroy(&s);
}

void test_top() {
    Stack s = create();
    Item *val;

    // Top tuščiam stekui
    assert(top(s, &val) == -1);

    push(&s, 42);
    assert(top(s, &val) == 0);
    assert(*val == 42);
    assert(count(s) == 1); // Top neturėtų keisti dydžio

    printf("test_top: OK\n");
    destroy(&s);
}

void test_clone() {
    Stack s = create();
    push(&s, 1);
    push(&s, 2);

    Stack clone_stack = clone(s);
    assert(count(clone_stack) == 2);

    Item *val;
    pop(&clone_stack, &val);
    assert(*val == 2);
    free(val);
    pop(&clone_stack, &val);
    assert(*val == 1);
    free(val);

    // Originalas lieka nepakitęs
    assert(count(s) == 2);
    printf("test_clone: OK\n");
    destroy(&s);
    destroy(&clone_stack);
}

void test_toString() {
    Stack s = create();
    char *str;

    push(&s, 9);
    push(&s, 8);
    push(&s, 7);
    str = toString(s, itemToString);
    assert(strcmp(str, "7, 8, 9") == 0);
    
    free(str); // Atlaisvinti toString grąžintą eilutę
    destroy(&s);

    printf("test_toString: OK\n");
}

void test_edge_cases() {
    Stack s = create();
    
    // Push to a valid stack
    assert(push(&s, 100) == 0);
    assert(count(s) == 1);

    // Destroy and block operations
    assert(destroy(&s) == 0);
    assert(push(&s, 200) == -1);  // Now returns -1
    assert(destroy(&s) == -1);    // Double-destroy fails

    printf("test_edge_cases: OK\n");
}

int main() {
    test_create_destroy();
    test_push_pop();
    test_top();
    test_clone();
    test_toString();
    test_edge_cases();
    
    printf("\nVisi testai praėjo sėkmingai!\n");
    return 0;
}