#ifndef STACK_H
#define STACK_H

#include <stdbool.h>
#include "list.h"


typedef int Item;
typedef unsigned long long stack_t;


typedef struct Stack {
    Node *head;
    stack_t size;
    bool destroyed;
} Stack;


Stack create(void);
int destroy(Stack * stack);
stack_t count(const Stack stack);
bool isEmpty(const Stack stack);
bool isFull(void);
int push(Stack * stack, const Item item);
int pop(Stack * stack, Item ** item);
int top(Stack stack, Item ** item);
Stack clone(Stack stack);

char * toString(Stack stack, char *(*itemToString)(Item *));
#endif
