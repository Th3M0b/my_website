import snackandcoffee.*;
import vendingmachine.VendingMachine;

public class Test {
    public static void main(String[] args) {

        // Factory method starts
        System.out.println("\n");
        VendingMachine snackMachine = new SnackVendingMachine("lobby");
        snackMachine.dispenseProduct();

        VendingMachine coffeeMachine = new CoffeeVendingMachine("Oficce", 10);
        coffeeMachine.dispenseProduct();
        // Factory method ends

        // Saving and loading
        CoffeeVendingMachine machine = new CoffeeVendingMachine("Office", 10);
        machine.refillCups(10);
        machine.saveState("machine.dat");

        try{
           VendingMachine coffeeNew = VendingMachine.loadState("machine.dat");
           machine.refillCups(100);
           System.out.println("old coffee machine: " + machine);
           System.out.println("new coffee machine: " + coffeeNew);
        } catch (Exception e){
            System.err.println("Error" + e.getMessage());
        }
    }
}