import snackandcoffee.*;
import vendingmachine.VendingMachine;

public class Test {
    public static void main(String[] args) {
        System.out.println("\n");
        VendingMachine snackMachine = new SnackVendingMachine("lobby");
        snackMachine.dispenseProduct();

        VendingMachine coffeeMachine = new CoffeeVendingMachine("Oficce", 10);
        coffeeMachine.dispenseProduct();
    }
}