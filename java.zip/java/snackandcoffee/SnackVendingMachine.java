package snackandcoffee;
import java.util.HashMap;
import java.util.Map;
import exceptions.InsufficientStockException;
import exceptions.TakeBackMoneyException;
import interfaces.VendingProduct;
import vendingmachine.VendingMachine;

public class SnackVendingMachine extends VendingMachine{
    private Map<String, Integer> snacks = new HashMap<>();
    private static final long serialVersionUID = 1L;

    public SnackVendingMachine(String location) {
        super(location);
    }

    public SnackVendingMachine(SnackVendingMachine other){
        super(other);
        this.snacks = new HashMap<>(other.snacks);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        SnackVendingMachine cloned = (SnackVendingMachine) super.clone();

        return cloned;
    }

    @Override
    public VendingProduct createProduct(){
        return new Snack("Chips");
    }

    public SnackVendingMachine(SnackVendingMachine other, boolean shallow) {
        super(other);
        if(shallow) {
            this.snacks = other.snacks;
        } else {
            this.snacks = new HashMap<>(other.snacks);
        }
    }

    public void addSnack(String snack, int quantity) {
        snacks.put(snack, snacks.getOrDefault(snack, 0) + quantity);
    }

    public boolean buySnack(String snack) throws InsufficientStockException{
        if (snacks.getOrDefault(snack, 0) > 0){
            snacks.put(snack, snacks.get(snack) -1);
            return true;
        }
        throw new InsufficientStockException(snack);
    }

    @Override
    public boolean takeBackMoney(int amount) throws TakeBackMoneyException{
    // Check if there have been any snack purchases (or another condition).
        if (snacks.isEmpty()) {
            return false;
        }
    // Proceed with refund if the conditions are met.
        return super.takeBackMoney(amount);
    }


    @Override
    public String toString(){
        return "SnackVendingMachine at " + getLocation() + " | Snacks: " + snacks;
    }

    public Map<String, Integer> getSnacks() {
        return new HashMap<>(snacks);
    }


}
