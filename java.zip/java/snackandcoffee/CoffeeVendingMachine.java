package snackandcoffee;
import exceptions.BalanceException;
import exceptions.CoffeeCupsException;
import interfaces.VendingProduct;
import vendingmachine.VendingMachine;

public class CoffeeVendingMachine extends VendingMachine{
    private static final long serialVersionUID = 1L;
    private int coffeeCups;
    private boolean freeCoffee= false;

    public CoffeeVendingMachine(String location, int initialCups){
        super(location);
        this.coffeeCups = initialCups;
    }

    public CoffeeVendingMachine(CoffeeVendingMachine other){
        super(other);
        this.coffeeCups = other.coffeeCups;
        this.freeCoffee = other.freeCoffee;
    }

    @Override
    public VendingProduct createProduct(){
        return new Coffee("black coffee");
    }

    public void refillCups(int amount){
        coffeeCups += amount;
    }

    public boolean dispenseCoffee() throws CoffeeCupsException{
        if(coffeeCups > 0){
            coffeeCups--;
            return true;
        }
        throw new CoffeeCupsException();
    }

    @Override
    public void add(double amount) throws BalanceException{
        super.add(amount);
        if (amount > 6) {
            freeCoffee = true;
        }
    }

    @Override
    public String toString(){
        return "CoffeeVendingMachine at " + getLocation() + " | Cups left: " + coffeeCups;
    }


}
