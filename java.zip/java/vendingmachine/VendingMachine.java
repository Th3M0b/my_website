package vendingmachine;
import interfaces.VendingProduct;
import interfaces.Withdrawable;


import java.io.Serializable;

import exceptions.BalanceException;
import exceptions.TakeBackMoneyException;


public abstract class VendingMachine implements Withdrawable, Cloneable, Serializable{
    // Fields
    private double balance = 10;
    private String location;
    public static final int MAX_CAPACITY = 10;
    private static final long serialVersionUID = 1L;

    // Constructors
    public VendingMachine() {
        this.location = "Unknown";
    }

    public VendingMachine(String location) {
        this();
        this.location = location;
    }

    protected VendingMachine(VendingMachine other){
        this.balance = other.balance;
        this.location = other.location;
    }

    public abstract VendingProduct createProduct();

    public void dispenseProduct(){
        VendingProduct product = createProduct();
        product.dispense();
    }

    // SAVE AND LOAD starts
    public void saveState(String filename){
        SaveTask saveTask = new SaveTask(this, filename);
        Thread saveThread = new Thread(saveTask);
        saveThread.start();
    }

    public static VendingMachine loadState(String filename) throws Exception {
        LoadTask task = new LoadTask(filename);
        Thread thread = new Thread(task);
        thread.start();
        thread.join();
        if (task.error != null) {
            throw task.error;
        }
        return task.result;
    }
    // SAVE AND LOAD ends

    // Getters and setters
    public double getBalance() {
        return balance;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override 
    public void add(double amount) throws BalanceException {
        if (amount > 0) {
            balance += amount;
        }
        else{
            throw new BalanceException(amount);
        }
    }


    @Override
    public final double takeBackMoney() {
        double refundedAmount = balance;
        balance = 0;
        return refundedAmount;
    }


    @Override
    public boolean takeBackMoney(int amount) throws TakeBackMoneyException {
        if (amount <= balance && amount > 0) {
            balance -= amount;
            return true;
        } else {
            throw new TakeBackMoneyException(amount);
        }
    }

    // Output method
    public void println() {
        System.out.println(this);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        try {
            VendingMachine cloned = (VendingMachine) super.clone();
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
