package vendingmachine;
import interfaces.VendingProduct;
import interfaces.Withdrawable;
import exceptions.BalanceException;
import exceptions.TakeBackMoneyException;


public abstract class VendingMachine implements Withdrawable, Cloneable{
    // Fields
    private double balance = 10;
    private String location;
    public static final int MAX_CAPACITY = 10;

    // Constructors
    public VendingMachine() {
        this.location = "Unknown";
    }

    public VendingMachine(String location) {
        this();
        this.location = location;
    }

    protected VendingMachine(VendingMachine other){
        this.balance = other.balance;
        this.location = other.location;
    }

    public abstract VendingProduct createProduct();

    public void dispenseProduct(){
        VendingProduct product = createProduct();
        product.dispense();
    }

    // Getters and setters
    public double getBalance() {
        return balance;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override 
    public void add(double amount) throws BalanceException {
        if (amount > 0) {
            balance += amount;
        }
        else{
            throw new BalanceException(amount);
        }
    }


    @Override
    public final double takeBackMoney() {
        double refundedAmount = balance;
        balance = 0;
        return refundedAmount;
    }


    @Override
    public boolean takeBackMoney(int amount) throws TakeBackMoneyException {
        if (amount <= balance && amount > 0) {
            balance -= amount;
            return true;
        } else {
            throw new TakeBackMoneyException(amount);
        }
    }

    // Output method
    public void println() {
        System.out.println(this);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        try {
            VendingMachine cloned = (VendingMachine) super.clone();
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
