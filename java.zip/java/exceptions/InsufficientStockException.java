package exceptions;

public class InsufficientStockException extends VendingMachineException {
    private String snack;

    public InsufficientStockException(String snack){
         super("Error: There is no more: "+ snack);
         this.snack = snack;
    }

    public String getSnack(){
        return snack;
    }
}
