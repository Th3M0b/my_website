package exceptions;

public class BalanceException extends VendingMachineException {
    private double balance;

    public BalanceException(double balance){
         super("Error: cannot add negative amount: "+ balance);
         this.balance = balance;
    }

    public double getBalance(){
        return balance;
    }
}
