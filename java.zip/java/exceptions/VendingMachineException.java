package exceptions;

public class VendingMachineException extends Exception {
    public VendingMachineException(String message){
        super(message);
    }
}