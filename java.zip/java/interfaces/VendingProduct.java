package interfaces;

public interface VendingProduct {
    void dispense();
}
