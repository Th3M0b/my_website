package interfaces;
import exceptions.TakeBackMoneyException;

public interface Withdrawable extends Addable{
    double takeBackMoney();
    boolean takeBackMoney(int amount) throws TakeBackMoneyException;
}
