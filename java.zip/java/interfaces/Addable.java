package interfaces;
import exceptions.BalanceException;

public interface Addable {
    void add(double amount) throws BalanceException;
}
