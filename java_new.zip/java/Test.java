import java.util.Scanner;

import exceptions.BalanceException;
import exceptions.CoffeeCupsException;
import exceptions.InsufficientStockException;
import snackandcoffee.*;
import vendingmachine.VendingMachine;


public class Test {
    public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);
        VendingMachine selectedMachine = null;
        boolean running = true;

        while (running) {
            System.out.println("\n=== PAGRINDINIS MENIU ===");
            System.out.println("1. Pasirinkti aparatą");
            System.out.println("2. Užkrauti išsaugotą automatą");
            System.out.println("3. Naudoti pasirinktą aparatą");
            System.out.println("4. Išeiti");
            System.out.print("Pasirinkimas: ");
            String pasirinkimas = scanner.nextLine();

            switch (pasirinkimas) {
                case "1":
                    System.out.println("Pasirinkite aparato tipą:");
                    System.out.println("1. Snack automatas");
                    System.out.println("2. Kavos automatas");
                    System.out.println("3. Atgal");

                    String pasirinktasTipas = scanner.nextLine();
                    switch (pasirinktasTipas) {
                        case "1":
                            selectedMachine = new SnackVendingMachine("Biuras");
                            System.out.println("Snack automatas pasirinktas!");
                            break;
                        case "2":
                            selectedMachine = new CoffeeVendingMachine("Universitetas", 5);
                            System.out.println("Kavos automatas pasirinktas!");
                            break;
                        case "3":
                            break;
                        default:
                            System.out.println("Neteisingas pasirinkimas!");
                    }
                    break;
                case "2":
                    if(selectedMachine == null){
                        try {
                            System.out.println("Koks failo pavadinimas?: ");
                            String filePathLoad = scanner.nextLine();
                            selectedMachine = VendingMachine.loadState(filePathLoad + ".dat");
                        } catch (Exception e) {
                            System.err.println("Error" + e.getMessage());
                        }
                    } else {
                        System.out.println("Jus jau pasirinkote naują automatą.");
                    }
                    break;

                case "3":
                    if (selectedMachine == null) {
                        System.out.println("Pirma pasirinkite automatą!");
                    } else {
                        boolean naudoti = true;
                        while (naudoti) {
                            System.out.println("\n=== AUTOMATO VALDYMAS ===");
                            System.out.println("1. Pridėti pinigų");
                            System.out.println("2. Atgauti pinigus");
                            System.out.println("3. Peržiūrėti informaciją");
                            if (selectedMachine instanceof SnackVendingMachine) {
                                System.out.println("4. Pridėti užkandį");
                                System.out.println("5. Nusipirkti užkandį");
                            } else if (selectedMachine instanceof CoffeeVendingMachine) {
                                System.out.println("4. Papildyti kavos puodelių");
                                System.out.println("5. Pasiimti kavos");
                            }
                            System.out.println("6. Išsaugoti automato būseną");
                            System.out.println("0. Atgal");

                            System.out.print("Pasirinkite veiksmą: ");
                            String veiksmas = scanner.nextLine();

                            switch (veiksmas) {
                                case "1":
                                    System.out.print("Įveskite sumą: ");
                                    double suma = Double.parseDouble(scanner.nextLine());
                                    try {
                                        selectedMachine.add(suma);
                                        System.out.println("Pinigai pridėti.");
                                    } catch (BalanceException e) {
                                        System.out.println("Klaida: " + e.getMessage());
                                    }
                                    break;

                                case "2":
                                    double grazinta = selectedMachine.takeBackMoney();
                                    System.out.println("Grąžinta: " + grazinta + " EUR");
                                    break;

                                case "3":
                                    selectedMachine.println();
                                    break;

                                case "4":
                                    if (selectedMachine instanceof SnackVendingMachine) {
                                        SnackVendingMachine snack = (SnackVendingMachine) selectedMachine;
                                        System.out.print("Įveskite užkandžio pavadinimą: ");
                                        String uzkandis = scanner.nextLine();
                                        System.out.print("Įveskite kiekį: ");
                                        int kiekis = Integer.parseInt(scanner.nextLine());
                                        snack.addSnack(uzkandis, kiekis);
                                        System.out.println("Užkandis pridėtas.");
                                    } else if (selectedMachine instanceof CoffeeVendingMachine) {
                                        CoffeeVendingMachine coffee = (CoffeeVendingMachine) selectedMachine;
                                        System.out.print("Kiek puodelių pridėti? ");
                                        int cups = Integer.parseInt(scanner.nextLine());
                                        coffee.refillCups(cups);
                                        System.out.println("Puodeliai papildyti.");
                                    }
                                    break;

                                case "5":
                                    if (selectedMachine instanceof SnackVendingMachine) {
                                        SnackVendingMachine snack = (SnackVendingMachine) selectedMachine;
                                        System.out.print("Kokio užkandžio norite? ");
                                        String uzkandis = scanner.nextLine();
                                        try {
                                            snack.buySnack(uzkandis);
                                            System.out.println("Užkandis nupirktas.");
                                        } catch (InsufficientStockException e) {
                                            System.out.println("Nėra tokio užkandžio sandėlyje.");
                                        }
                                    } else if (selectedMachine instanceof CoffeeVendingMachine) {
                                        CoffeeVendingMachine coffee = (CoffeeVendingMachine) selectedMachine;
                                        try {
                                            coffee.dispenseCoffee();
                                            System.out.println("Kava išleista.");
                                        } catch (CoffeeCupsException e) {
                                            System.out.println("Nebėra kavos!");
                                        }
                                    }
                                    break;
                                case "6":
                                    System.out.println("Nurodykite pavadinimą failo: ");
                                    String filePathSave = scanner.nextLine();
                                    selectedMachine.saveState(filePathSave + ".dat");
                                    break;

                                case "0":
                                    naudoti = false;
                                    break;

                                default:
                                    System.out.println("Neteisingas pasirinkimas!");
                            }
                        }
                    }
                    break;

                case "4":
                    running = false;
                    System.out.println("Programa baigta.");
                    break;

                default:
                    System.out.println("Neteisingas pasirinkimas!");
            }
        }

        scanner.close();


    }
}