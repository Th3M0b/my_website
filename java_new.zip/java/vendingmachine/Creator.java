package vendingmachine;

import interfaces.VendingProduct;

public abstract class Creator {
    public abstract VendingProduct createProduct();

    
}
