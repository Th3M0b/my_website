package snackandcoffee;

import interfaces.VendingProduct;
import vendingmachine.Creator;

public class SnackProduce extends Creator{
    @Override
    public VendingProduct createProduct(){
        return new Snack("Chips");
    }
}
