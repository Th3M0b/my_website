#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <stdbool.h>

typedef struct {
    int id;
    int priority;  // 0 - aukščiausias prioritetas (VIP)
    double arrival_time;
    double service_time;
} PriorityItem;

typedef struct {
    PriorityItem* items;
    int capacity;
    int size;
} PriorityQueue;

PriorityQueue* createPriorityQueue(int capacity);
void freePriorityQueue(PriorityQueue* q);
bool enqueuePriority(PriorityQueue* q, PriorityItem item);
PriorityItem dequeuePriority(PriorityQueue* q);
bool isPriorityQueueEmpty(PriorityQueue* q);
PriorityItem peekPriority(PriorityQueue* q);

#endif