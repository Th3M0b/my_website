#ifndef VIP_BANK_H
#define VIP_BANK_H

#include "queue.h"
#include "priorityQueue.h"

typedef enum { NORMAL_CLIENT, VIP_CLIENT } ClientType;
typedef enum { PROCESS_1, PROCESS_2 } ProcessType;

typedef struct {
    int id;
    ClientType type;
    double arrival_time;
    double service_time;
    double start_time;
    double end_time;
} Client;

typedef struct {
    int total_clerks;
    int normal_clerks;
    int vip_clerks;
    double p_normal;
    double t_normal;
    double t_vip;
} SimulationParams;

typedef struct {
    double total_downtime;
    double total_overtime;
    double avg_normal_wait;
    double max_vip_wait;
} SimulationResults;

SimulationResults runSimulation(ProcessType process, SimulationParams params);

#endif