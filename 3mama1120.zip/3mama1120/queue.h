#ifndef QUEUE_H
#define QUEUE_H

#include <stdbool.h>

typedef struct {
    int id;
    double arrival_time;
    double service_time;
} QueueItem;

typedef struct {
    QueueItem* items;
    int capacity;
    int front;
    int rear;
    int size;
} Queue;

Queue* createQueue(int capacity);
void freeQueue(Queue* q);
bool enqueue(Queue* q, QueueItem item);
QueueItem dequeue(Queue* q);
bool isQueueEmpty(Queue* q);
QueueItem peek(Queue* q);

#endif