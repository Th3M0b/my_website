#include "priorityQueue.h"
#include <stdlib.h>

PriorityQueue* createPriorityQueue(int capacity) {
    PriorityQueue* q = (PriorityQueue*)malloc(sizeof(PriorityQueue));
    q->items = (PriorityItem*)malloc(sizeof(PriorityItem) * capacity);
    q->capacity = capacity;
    q->size = 0;
    return q;
}

void freePriorityQueue(PriorityQueue* q) {
    free(q->items);
    free(q);
}

static void swap(PriorityItem* a, PriorityItem* b) {
    PriorityItem temp = *a;
    *a = *b;
    *b = temp;
}

static void heapifyUp(PriorityQueue* q, int index) {
    while (index > 0) {
        int parent = (index - 1) / 2;
        if (q->items[index].priority >= q->items[parent].priority) break;
        swap(&q->items[index], &q->items[parent]);
        index = parent;
    }
}

static void heapifyDown(PriorityQueue* q, int index) {
    while (1) {
        int left = 2 * index + 1;
        int right = 2 * index + 2;
        int smallest = index;

        if (left < q->size && q->items[left].priority < q->items[smallest].priority)
            smallest = left;
        if (right < q->size && q->items[right].priority < q->items[smallest].priority)
            smallest = right;
        if (smallest == index) break;

        swap(&q->items[index], &q->items[smallest]);
        index = smallest;
    }
}

bool enqueuePriority(PriorityQueue* q, PriorityItem item) {
    if (q->size >= q->capacity) return false;
    q->items[q->size] = item;
    heapifyUp(q, q->size);
    q->size++;
    return true;
}

PriorityItem dequeuePriority(PriorityQueue* q) {
    PriorityItem item = q->items[0];
    q->size--;
    q->items[0] = q->items[q->size];
    heapifyDown(q, 0);
    return item;
}

bool isPriorityQueueEmpty(PriorityQueue* q) {
    return q->size == 0;
}

PriorityItem peekPriority(PriorityQueue* q) {
    return q->items[0];
}