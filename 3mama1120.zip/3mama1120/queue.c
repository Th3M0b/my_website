#include "queue.h"
#include <stdlib.h>

Queue* createQueue(int capacity) {
    Queue* q = (Queue*)malloc(sizeof(Queue));
    q->items = (QueueItem*)malloc(sizeof(QueueItem) * capacity);
    q->capacity = capacity;
    q->front = 0;
    q->rear = -1;
    q->size = 0;
    return q;
}

void freeQueue(Queue* q) {
    free(q->items);
    free(q);
}

bool enqueue(Queue* q, QueueItem item) {
    if (q->size >= q->capacity) return false;
    q->rear = (q->rear + 1) % q->capacity;
    q->items[q->rear] = item;
    q->size++;
    return true;
}

QueueItem dequeue(Queue* q) {
    QueueItem item = q->items[q->front];
    q->front = (q->front + 1) % q->capacity;
    q->size--;
    return item;
}

bool isQueueEmpty(Queue* q) {
    return q->size == 0;
}

QueueItem peek(Queue* q) {
    return q->items[q->front];
}