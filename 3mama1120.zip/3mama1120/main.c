#include "VIP_bank.h"
#include <stdio.h>

int main() {
    SimulationParams params = {
        .total_clerks = 4,
        .normal_clerks = 3,
        .vip_clerks = 1,
        .p_normal = 0.8,
        .t_normal = 10.0,
        .t_vip = 5.0
    };

    printf("Programa pradedama...\n");
    
    printf("Vykdomas Procesas 1...\n");
    SimulationResults res1 = runSimulation(PROCESS_1, params);
    
    printf("Vykdomas Procesas 2...\n");
    SimulationResults res2 = runSimulation(PROCESS_2, params);

    printf("\nProcesas 1 rezultatai:\n");
    printf("Prastovos laikas: %.2f min\n", res1.total_downtime);
    printf("Viršvalandžiai: %.2f min\n", res1.total_overtime);
    printf("Vid. normalus laukimas: %.2f min\n", res1.avg_normal_wait);
    printf("Maks. VIP laukimas: %.2f min\n", res1.max_vip_wait);

    printf("\nProcesas 2 rezultatai:\n");
    printf("Prastovos laikas: %.2f min\n", res2.total_downtime);
    printf("Viršvalandžiai: %.2f min\n", res2.total_overtime);
    printf("Vid. normalus laukimas: %.2f min\n", res2.avg_normal_wait);
    printf("Maks. VIP laukimas: %.2f min\n", res2.max_vip_wait);

    return 0;
}