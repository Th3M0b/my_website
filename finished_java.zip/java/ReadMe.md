﻿# Vending Machine Project (Java)

## Projekto paskirtis

Ši Java konsolinė programa simuliuoja dviejų tipų prekybos automatus: kavos ir užkandžių. Programa leidžia vartotojui pasirinkti automatą, įnešti pinigų, įsigyti produktų, papildyti atsargas bei išsaugoti/užkrauti automato būseną.

## Paleidimo instrukcija

1. Įsitikinkite, kad naudojate JDK 17 arba naujesnę versiją.
2. Iškompiliuokite visas `.java` bylas:

   ```bash
   javac Test.java snackandcoffee/*.java vendingmachine/*.java exceptions/*.java interfaces/*.java
   ```
3. Paleiskite programą:

   ```bash
   java Test
   ```

## Funkcionalumas

* Galimybė pasirinkti automatą (užkandžių ar kavos)
* Piniginės valdymas: įnešti ir atgauti pinigus
* Produktų pirkimas ir atsargų papildymas
* Duomenų išsaugojimas ir atkūrimas iš failų
* Išimčių valdymas: netinkama suma, tuščios atsargos ir pan.

## Pagrindinės klasės

* **VendingMachine** *(abstract)* – bazinė klasė automatams
* **SnackVendingMachine** – paveldėta klasė užkandžių automato logikai
* **CoffeeVendingMachine** – paveldėta klasė kavos automato logikai
* **Snack**, **Coffee** – produktų klasės
* **SnackProduce**, **CoffeeProduce** – produktų gamyba (Factory metodas)
* **exceptions/** – įvairios išimtys (pvz., `BalanceException`, `InsufficientStockException`)
* **interfaces/** – sąsajos: `Addable`, `Withdrawable`, `VendingProduct`
* **SaveTask**, **LoadTask** – atskiros klasės būsenos saugojimui ir užkrovimui (Runnable)

## Klasių sąveikos diagrama (UML)

```
┌───────────────────────┐       ┌───────────────────────┐
│     <<interface>>     │       │     <<interface>>     │◄─────────────────────────────────────────┐
│      Addable          │       │     VendingProduct    │                                          │
├───────────────────────┤       ├───────────────────────┤◄───────────┐                             │
│ + add(amount: double) │       │ + dispense(): void    │            │                             │
└──────────┬────────────┘       └──────────┬────────────┘            │                             │
           ▲                               ▲                         │                             │
           │                            ┌──┘                         │                             │
           │                            │                 ┌───────────────────────┐    ┌───────────────────────┐     
           │                            │                 │        Snack          │    │        Coffee         │     
           │                            │                 ├───────────────────────┤    ├───────────────────────┤     
           │                            │                 │ - name: String        │    │ - name: String        │     
           │                            │                 ├───────────────────────┤    ├───────────────────────┤     
           │                            │                 │ + dispense(): void    │    │ + dispense(): void    │     
           │                            │                 └───────────────────────┘    └───────────────────────┘
┌──────────┴──────────────────────┐     │                                                              
│      <<interface>>              │     │    
│      Withdrawable               │     │    
├─────────────────────────────────┤     │    
│ + takeBackMoney(): double       │     │    
│ + takeBackMoney(amount: int)    │     │    
└──────────┬──────────────────────┘     │    
           ▲                            │    
           │                            |    
┌──────────┴──────────────────────┐ ┌───┴───────────────────────┐
│       VendingMachine            │ │        Creator            │
├─────────────────────────────────┤ ├───────────────────────────┤
│ - balance: double               │ │ + createProduct():        │
│ - location: String              │ │     VendingProduct        │
│ + MAX_CAPACITY: int             │ └──────────┬────────────────┘
│ - serialVersionUID: long        │            ▲       ▲
├─────────────────────────────────┤            │       ┴────────────────────────┐
│ + saveState(filename: String)   │            ┴────────────────┐               │
│ + loadState(filename: String)   │                             │               │
└──────────┬──────────────────────┘                             │               │
           ▲                                                    │               │
    ┌──────┴───────────────────────┐                            │               │
    │                              │                            │               │
┌───▼───────┐              ┌───────▼──────┐        ┌────────────▼──────┐ ┌───────────────┐
│ Snack     │              │ Coffee       │        │ SnackProduce      │ │ CoffeeProduce │
│ Vending   │              │ Vending      │        ├───────────────────┤ ├───────────────┤
│ Machine   │              │ Machine      │        │ + createProduct() │ │ + createProduct()
├───────────┤              ├──────────────┤        └───────────────────┘ └───────────────┘
│ - snacks: │              │ - coffeeCups │
│  Map<String,Integer>     │ - freeCoffee │                 
│ - serialVersionUID=1L    │ - serialVersionUID=1L          
└───────────┘              └──────────────┘                 

```

## Naudoti projektavimo šablonai

* **Factory Method** – klasės `SnackProduce` ir `CoffeeProduce` atsakingos už objektų kūrimą.
* **Template Method** – abstrakti klasė `VendingMachine` apibrėžia bendrą logiką, o konkrečios klasės ją įgyvendina.
* **Strategy Pattern** – galima laikyti `Addable` ir `Withdrawable` sąsajų naudojimą strategijų principu.
* **Multithreading (Runnable)** – `SaveTask` ir `LoadTask` naudoja daugiasriegį veikimą.

## Plėtimo galimybės

* Pridėti grafinę naudotojo sąsają (GUI su JavaFX ar Swing)
* Įdiegti daugiau produktų tipų (pvz., gėrimų automatą)
* Internetinė integracija (pvz., produktų atnaujinimas iš API)
* Naudotojų autentifikacija