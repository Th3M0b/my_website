import java.util.Scanner;
import exceptions.BalanceException;
import exceptions.CoffeeCupsException;
import exceptions.InsufficientStockException;
import snackandcoffee.*;
import vendingmachine.VendingMachine;

public class Test {

    public static final String RESET = "\u001B[0m";
    public static final String GREEN = "\u001B[32m";
    public static final String CYAN = "\u001B[36m";
    public static final String RED = "\u001B[31m";
    public static final String YELLOW = "\u001B[33m";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        VendingMachine selectedMachine = null;
        boolean running = true;

        while (running) {
            printMainMenu();
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("\n Choose machine type:");
                    System.out.println("  1.  Snack vending machine");
                    System.out.println("  2.  Coffee vending machine");
                    System.out.println("  3.  Back");

                    String typeChoice = scanner.nextLine();
                    switch (typeChoice) {
                        case "1":
                            selectedMachine = new SnackVendingMachine("Office");
                            System.out.println(GREEN + " Snack machine selected!" + RESET);
                            break;
                        case "2":
                            selectedMachine = new CoffeeVendingMachine("University", 5);
                            System.out.println(GREEN + " Coffee machine selected!" + RESET);
                            break;
                        case "3":
                            break;
                        default:
                            System.out.println(RED + " Invalid choice!" + RESET);
                    }
                    break;

                case "2":
                    if (selectedMachine == null) {
                        try {
                            System.out.print(" Enter file name: ");
                            String filePathLoad = scanner.nextLine();
                            selectedMachine = VendingMachine.loadState(filePathLoad + ".dat");
                            System.out.println(GREEN + " Machine loaded!" + RESET);
                        } catch (Exception e) {
                            System.err.println(RED + " Error: " + e.getMessage() + RESET);
                        }
                    } else {
                        System.out.println(YELLOW + " You have already selected a machine." + RESET);
                    }
                    break;

                case "3":
                    if (selectedMachine == null) {
                        System.out.println(RED + " Please select a machine first!" + RESET);
                    } else {
                        boolean using = true;
                        while (using) {
                            printControlMenu(selectedMachine);
                            String action = scanner.nextLine();

                            switch (action) {
                                case "1":
                                    System.out.print(" Enter amount: ");
                                    double amount = Double.parseDouble(scanner.nextLine());
                                    try {
                                        selectedMachine.add(amount);
                                        System.out.println(GREEN + " Money added." + RESET);
                                    } catch (BalanceException e) {
                                        System.out.println(RED + " Error: " + e.getMessage() + RESET);
                                    }
                                    break;

                                case "2":
                                    double returned = selectedMachine.takeBackMoney();
                                    System.out.println(" Returned: " + returned + " EUR");
                                    break;

                                case "3":
                                    selectedMachine.println();
                                    break;

                                case "4":
                                    if (selectedMachine instanceof SnackVendingMachine) {
                                        SnackVendingMachine snack = (SnackVendingMachine) selectedMachine;
                                        System.out.print(" Enter snack name: ");
                                        String snackName = scanner.nextLine();
                                        System.out.print(" Enter quantity: ");
                                        int quantity = Integer.parseInt(scanner.nextLine());
                                        snack.addSnack(snackName, quantity);
                                        System.out.println(GREEN + " Snack added." + RESET);
                                    } else if (selectedMachine instanceof CoffeeVendingMachine) {
                                        CoffeeVendingMachine coffee = (CoffeeVendingMachine) selectedMachine;
                                        System.out.print(" Enter number of cups to refill: ");
                                        int cups = Integer.parseInt(scanner.nextLine());
                                        coffee.refillCups(cups);
                                        System.out.println(GREEN + " Cups refilled." + RESET);
                                    }
                                    break;

                                case "5":
                                    if (selectedMachine instanceof SnackVendingMachine) {
                                        SnackVendingMachine snack = (SnackVendingMachine) selectedMachine;
                                        System.out.print(" Enter snack name: ");
                                        String snackName = scanner.nextLine();
                                        try {
                                            snack.buySnack(snackName);
                                            System.out.println(GREEN + " Snack purchased." + RESET);
                                        } catch (InsufficientStockException e) {
                                            System.out.println(RED + " Snack not in stock." + RESET);
                                        }
                                    } else if (selectedMachine instanceof CoffeeVendingMachine) {
                                        CoffeeVendingMachine coffee = (CoffeeVendingMachine) selectedMachine;
                                        try {
                                            coffee.dispenseCoffee();
                                            System.out.println(GREEN + " Coffee dispensed." + RESET);
                                        } catch (CoffeeCupsException e) {
                                            System.out.println(RED + " No coffee left!" + RESET);
                                        }
                                    }
                                    break;

                                case "6":
                                    System.out.print(" Enter file name: ");
                                    String filePathSave = scanner.nextLine();
                                    selectedMachine.saveState(filePathSave + ".dat");
                                    System.out.println(GREEN + " State saved." + RESET);
                                    break;

                                case "0":
                                    using = false;
                                    break;

                                default:
                                    System.out.println(RED + " Invalid action!" + RESET);
                            }
                        }
                    }
                    break;

                case "4":
                    running = false;
                    System.out.println(GREEN + " Program terminated." + RESET);
                    break;

                default:
                    System.out.println(RED + " Invalid choice!" + RESET);
            }
        }

        scanner.close();
    }

    public static void printMainMenu() {
        System.out.println("\n╔════════════════════════════════════╗");
        System.out.println("║         VENDING MACHINE CONTROL     ║");
        System.out.println("╠════════════════════════════════════╣");
        System.out.println("║ 1.    Select machine                ║");
        System.out.println("║ 2.    Load saved machine            ║");
        System.out.println("║ 3.    Use selected machine          ║");
        System.out.println("║ 4.    Exit                          ║");
        System.out.println("╚════════════════════════════════════╝");
        System.out.print(" Your choice: ");
    }

    public static void printControlMenu(VendingMachine machine) {
        System.out.println("\n === MACHINE CONTROL ===");
        System.out.println("1.  Insert money");
        System.out.println("2.  Return money");
        System.out.println("3.  View info");
        if (machine instanceof SnackVendingMachine) {
            System.out.println("4.  Add snack");
            System.out.println("5.  Buy snack");
        } else if (machine instanceof CoffeeVendingMachine) {
            System.out.println("4.  Refill coffee cups");
            System.out.println("5.  Get coffee");
        }
        System.out.println("6.  Save machine state");
        System.out.println("0.  Back");
        System.out.print("🡆 Select action: ");
    }
}
