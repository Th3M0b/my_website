package exceptions;

public class TakeBackMoneyException extends VendingMachineException{
    private double amount;

    public TakeBackMoneyException(double amount){
        super("Error: cannot take back negative amount or more than you have: "+ amount);
        this.amount = amount;
    }

    public double getAmount(){
        return amount;
    }
}
