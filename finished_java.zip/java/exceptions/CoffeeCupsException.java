package exceptions;

public class CoffeeCupsException extends VendingMachineException{
    public CoffeeCupsException(){
        super("Error: There are no more cups");
    }
}
