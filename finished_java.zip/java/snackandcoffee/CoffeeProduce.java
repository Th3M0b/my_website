package snackandcoffee;

import interfaces.VendingProduct;
import vendingmachine.Creator;

public class CoffeeProduce extends Creator{
    @Override
    public VendingProduct createProduct(){
        return new Coffee("black coffee");
    }
}
