package snackandcoffee;

import interfaces.VendingProduct;

public class Snack implements VendingProduct{
    private String name;


    public Snack(String name){
        this.name = name;
    }

    @Override
    public void dispense(){
        System.out.println("=> " + name + " drops to the tray!");
    }
}
