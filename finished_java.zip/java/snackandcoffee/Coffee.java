package snackandcoffee;

import interfaces.VendingProduct;

public class Coffee implements VendingProduct{
    private String name;

    public Coffee(String name){
        this.name = name;
    }

    @Override
    public void dispense(){
        System.out.println("=> Pouring " + name + " into cup...");
    }
}
