package vendingmachine;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class LoadTask implements Runnable {
    final String filename;
    VendingMachine result;
    Exception error;

    public LoadTask(String filename) {
        this.filename = filename;
    }

    @Override
    public void run() {
        try (FileInputStream fin = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fin)) {
            this.result = (VendingMachine) ois.readObject();
            System.out.println("Loaded successfully");
        } catch (Exception e) {
            this.error = e;
            System.err.println("Load error: " + e.getMessage());
        }
    }
}