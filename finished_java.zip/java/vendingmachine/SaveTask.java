package vendingmachine;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SaveTask implements Runnable {
    private final VendingMachine machine;
    private final String filename;

    public SaveTask(VendingMachine machine, String filename) {
        this.machine = machine;
        this.filename = filename;
    }

    @Override
    public void run() {
        try (FileOutputStream fout = new FileOutputStream(filename);
            ObjectOutputStream oos = new ObjectOutputStream(fout)) {
            oos.writeObject(machine);
            System.out.println("Saved successfully");
        } catch (Exception e) {
            System.err.println("Save error: " + e.getMessage());
        }
    }
}